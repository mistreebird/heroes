export * from './hero-detail.component';
