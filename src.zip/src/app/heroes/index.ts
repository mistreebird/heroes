export * from './heroes.component';
